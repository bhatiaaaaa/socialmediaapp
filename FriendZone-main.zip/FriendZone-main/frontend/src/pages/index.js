export { default as Home } from "./Home";
export { default as SignIn } from "./SignIn";
export { default as SignUp } from "./SignUp";
export { default as Friends } from "./Friends";
export { default as Notifications } from "./Notifications";
